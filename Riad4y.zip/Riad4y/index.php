<?php
// Mulai session
session_start();

// Inisialisasi variabel level
$level = "";

// Cek apakah pengguna sudah login
if (!isset($_SESSION["user"]["username"])) {
  // Redirect ke halaman login jika tidak
  header("Location: logine.php");
  exit();
}

// Ambil level pengguna dari session
if (isset($_SESSION['user']['level'])) {
  $level = $_SESSION['user']['level'];
}

// Inisialisasi variabel $show_admin_section
$show_admin_section = false;

// Periksa apakah pengguna adalah admin
if ($level == "admin") {
  $show_admin_section = true;
}

// Fungsi untuk menentukan kelas yang akan ditambahkan ke tombol pengumuman
function getButtonClass($level)
{
  // Implementasi fungsi sesuai kebutuhan
}
// Display username and level
$username = $_SESSION["user"]["username"];
$level = $_SESSION["user"]["level"];
?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-bold-rounded/css/uicons-bold-rounded.css'>
  <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
  <link rel="stylesheet" href="style.css">
  <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.1.0/uicons-solid-rounded/css/uicons-solid-rounded.css'>
  <link rel="shortcut icon" href="asset/LOGO.png" type="image/x-icon">
  <link rel="canonical" href="https://codepen.io/coding_dev_/pen/OJqdqLO">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css">
  <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.1.0/uicons-brands/css/uicons-brands.css'>
  <title>RIYADH</title>
</head>

<body>



  <header id="headere">
    <div class="logo-smk">
      <img src="asset/LOGO.png">
    </div>
    <div class="menu-buka" id="buka">
      <a href="#home" onclick="buka()" class="nav-vert active-link">
        <p class="kata">Home</p>
        <div class="ikhon"><i class="fi fi-br-house-chimney"></i></div>
      </a>
      <a href="#about" onclick="buka()" class="nav-vert">
        <p class="kata">Info</p>
        <div class="ikhon"><i class="fi fi-br-square-info"></i></div>
      </a>
      <a href="#choice" onclick="buka()" class="nav-vert">
        <p class="kata">Section <div class="ikhon"><i class="fi fi-br-objects-column"></i></div>
        </p>
      </a>
      <a href="#video" onclick="buka()" class="nav-vert">
        <p class="kata">Video <div class="ikhon"><i class="fi fi-br-play-alt"></i></div>
        </p>
      </a>
    </div>

    <div class="acc" id="profileDiv" onclick="toggleProfile()">
      <div class="login" id="coy">

        <p>
          <?php echo $username; ?>
        </p>
        <i class="fi fi-br-user"></i>
      </div>
    </div>






    <div class="menu" onclick="buka()">
      <div class="boxeh">
        <div class="pos2" id="silang">
          <div class="baris1" id="baris1"></div>
          <div class="baris2" id="baris2"></div>
          <div class="baris3" id="baris3"></div>
        </div>
      </div>
    </div>
  </header>



  <main class="maine">

    <div class="isi-profil" id="ispro">
      <div class="silang-profil" onclick="toggleProfile()">
        <div class="baris-profil"></div>
        <div class="baris-profil"></div>
      </div>
      <div class="isi-prof">
        <div class="profilekang">
          <div class='verivikasi'>
            <div class='isi'>
              <img src="asset/profile3.png" class="poto-profil"></img>
            </div>
          </div>
        </div>
        <div class="data-diri">
          <div class="nama">
            <h3 class="welkam">Selamat Datang</h3>
            <!-- <a href="halaman_admin.php">op</a> -->
            <h3 class="nama-prof"><?php echo $username; ?><br></h3>
            <p class="nama-prof-p"><?php echo $level; ?></p>
          </div>
          <hr>
          <a href="logout.php" class="logout"><i class="fi fi-br-exit"></i>
            <p class="logout-p">Logout?</p>
          </a>
        </div>
      </div>
    </div>

    <section class="sc0 sc0index" id="home">
      <div class="sc0-kiri">
        <div class="nama-apk">
          <h1 class="op">RIYADH</h1>
          <p class="op2">Belajar huruf-huruf arab dengan mudah <br>
            dan praktis hanya di Riyadh.</p>
        </div>
        <div class="btn-main">
          <div id="btnm" class="btn-about">
            <a href="#about" class="btnAbout">Our About</a>
          </div>
          <div id="btnm" class="btn-explore">
            <a href="#choice" class="btnExplore">Exlpore</a>
          </div>
        </div>
      </div>
      <div class="sc0-kanan">
        <span class="lampune"><img src="asset/light_11104988.png" alt="" srcset=""></span>
        <span class="lampune"><img src="asset/light_11104988.png" alt="" srcset=""></span>
        <span class="lampune"><img src="asset/light_11104988.png" alt="" srcset=""></span>
        <img class="imej-kan" src="asset/quran_7153468.png" alt="">
        <!-- <div class="bayang"></div> -->
      </div>
    </section>

    <section class="sc1" id="about">
      <div class="sc1-kotak">
        <span class="sepan"></span>
        <span class="sepan"></span>
        <span class="sepan"></span>
        <span class="sepan"></span>
        <span class="sepan"></span>
        <div class="text-sc1">
          <h2 class="sc1-h2">RIYADH</h2>
          <div class="sc1-garis" id="sc1garis"></div>
          <p class="sc1-p">
            Riyadh adalah web pembelajaran bahasa arab buatan SMK Negeri 5 Surakarta,
            web ini dibuat dan dikembangkan oleh Abi, Indra, dan Nico. web ini berisi
            huruf-huruf hijriah, angka-angka arab, cara membaca, dan lain-lain sangat kompit bukann?.
            oh iya, web ini juga ada versi aplikasinya lho dan gak kalah komplit.<br><BR>
            --RIYADH. SATU KATA, SATU PAHALA--
          </p>
        </div>
      </div>
    </section>
    <section class="sc2" id="choice">
      <main class="flex4">
        <div class="card">
          <div class="content">
          </div>
          <div class="kotak_login bokse1">
            <div class="atasan">
              <hr class="hratu">
              <h5 class="tulisan_login">Ayat-ayat</h5>
            </div>
            <div class="boxse"></div>
            <p>Section ini berisi ayat-ayat alquran yang lengkap, terdiri dari huruf-huruf arab beserta artinya</p>

            <a href="Al-Quran-JSON-Indonesia-Kemenag-master/index.html" class="iyako">
              <button>
                <span class="circle1"></span>
                <span class="circle2"></span>
                <span class="circle3"></span>
                <span class="circle4"></span>
                <span class="circle5"></span>
                <span class="text">Enter</span>
              </button>
            </a>
          </div>
        </div>
        </div>
        <div class="card">
          <div class="content">
          </div>
          <div class="kotak_login bokse1">
            <div class="atasan">
              <hr class="hratu">
              <h5 class="tulisan_login">Hijayah</h5>
            </div>
            <div class="boxse"></div>
            <p>Kumpulan Huruf-huruf Hijaiyah yang merupakan huruf penyusun kata dalam Al-Quran</p>

            <a href="hijriah/hijriah.html" class="iyako">
              <button>
                <span class="circle1"></span>
                <span class="circle2"></span>
                <span class="circle3"></span>
                <span class="circle4"></span>
                <span class="circle5"></span>
                <span class="text">Enter</span>
              </button>
            </a>
          </div>
        </div>
        </div>
        <div class="card">
          <div class="content">
          </div>
          <div class="kotak_login bokse1">
            <div class="atasan">
              <hr class="hratu">
              <h5 class="tulisan_login">Iqro</h5>
            </div>
            <div class="boxse"></div>
            <p>Berisi kumpulan Iqro untuk pemula, Dari Iqro 1 sampai 6</p>

            <a href="iqro/iqro.html" class="iyako">
              <button>
                <span class="circle1"></span>
                <span class="circle2"></span>
                <span class="circle3"></span>
                <span class="circle4"></span>
                <span class="circle5"></span>
                <span class="text">Enter</span>
              </button>
            </a>
          </div>
        </div>
        </div>

        <div class="card">
          <div class="content">
          </div>
          <div class="kotak_login bokse1">
            <div class="atasan">
              <hr class="hratu">
              <h5 class="tulisan_login">Angka Arab</h5>
            </div>
            <div class="boxse"></div>
            <p>Berbagai Angka-angka dalam bahasa arab yang sudah dikemas dalam satu section dengan penjelasan</p>

            <a href="angka/angar.html" class="iyako">
              <button>
                <span class="circle1"></span>
                <span class="circle2"></span>
                <span class="circle3"></span>
                <span class="circle4"></span>
                <span class="circle5"></span>
                <span class="text">Enter</span>
              </button>
            </a>
          </div>
        </div>
        </div>

        <div class="card">
          <div class="content">
          </div>
          <div class="kotak_login bokse1">
            <div class="atasan">
              <hr class="hratu">
              <h5 class="tulisan_login">Jadwal Sholat</h5>
            </div>
            <div class="boxse"></div>
            <p>Berisi jadwal waktu sholat untuk berbagai daerah di Indonesia</p>

            <a href="jadwal/jadwal.php" class="iyako">
              <button>
                <span class="circle1"></span>
                <span class="circle2"></span>
                <span class="circle3"></span>
                <span class="circle4"></span>
                <span class="circle5"></span>
                <span class="text">Enter</span>
              </button>
            </a>
          </div>
        </div>
        </div>

        <div class="card">
          <div class="content">
          </div>
          <div class="kotak_login bokse1">
            <div class="atasan">
              <hr class="hratu">
              <h5 class="tulisan_login">Tugas</h5>
            </div>
            <div class="boxse"></div>
            <p>Berisi daftar tugas dari guru anda</p>

            <a href="pengumuman/halaman_user.php" class="iyako">
              <button>
                <span class="circle1"></span>
                <span class="circle2"></span>
                <span class="circle3"></span>
                <span class="circle4"></span>
                <span class="circle5"></span>
                <span class="text">Enter</span>
              </button>
            </a>
          </div>
        </div>

        <?php if ($show_admin_section) : ?>
          <div class="card">
            <div class="content">
            </div>
            <div class="kotak_login bokse1">
              <div class="atasan">
                <hr class="hratu">
                <h5 class="tulisan_login">Admin</h5>
              </div>
              <div class="boxse"></div>
              <p>Mengirim sebuah kiriman untuk class pegawai</p>

              <a href="halaman_admin.php" class="iyako">
                <button>
                  <span class="circle1"></span>
                  <span class="circle2"></span>
                  <span class="circle3"></span>
                  <span class="circle4"></span>
                  <span class="circle5"></span>
                  <span class="text">Enter</span>
                </button>
              </a>
            </div>
          </div>
          </div>
        <?php endif; ?>
        </div>



        <!-- Tambahkan section baru untuk admin jika $show_admin_section bernilai true -->




      </main>

    </section>

    <section id="video">
      <div class="recipe-container">
        <h1>Video belajar Al-quran</h1>
        <div class="swiper">
          <div class="swiper-wrapper">
            <div class="swiper-slide post">
              <iframe class="post-img" src="https://www.youtube.com/embed/REn8dVlaKyA">
              </iframe>

              <div class="post-body">
                <img class="post-avatar" src="https://github.com/ecemgo/mini-samples-great-tricks/assets/13468728/f9d29d0e-f03b-4990-9bc5-ade57a276b41" alt="avatar" />
                <div class="post-detail">
                  <h2 class="post-name">9 Keutamaan membaca al-quran</h2>
                  <p class="post-author">Ustadz Ulin Nuha al-Hafidz</p>
                </div>

                <div class="post-actions">
                  <a class="post-like" href="javascript:void(0)"><i class="fas fa-heart"></i></a>

                </div>
              </div>
            </div>

            <div class="swiper-slide post">
              <iframe class="post-img" src="https://www.youtube.com/embed/wKLL9Rky_gI">
              </iframe>

              <div class="post-body">
                <img class="post-avatar" src="https://github.com/ecemgo/mini-samples-great-tricks/assets/13468728/3c7b6ef9-cd2d-4d70-819a-2aa9c2309083" alt="avatar" />
                <div class="post-detail">
                  <h2 class="post-name">Adab membaca <al-quran></al-quran></h2>
                  <p class="post-author">Ustadz Ulin Nuha al-Hafidz</p>
                </div>

                <div class="post-actions">
                  <a class="post-like" href="javascript:void(0)"><i class="fas fa-heart"></i></a>

                </div>
              </div>
            </div>

            <div class="swiper-slide post">
              <iframe class="post-img" src="https://www.youtube.com/embed/XN9V6Jh4DRA">
              </iframe>

              <div class="post-body">
                <img class="post-avatar" src="https://github.com/ecemgo/mini-samples-great-tricks/assets/13468728/01332597-5aeb-483b-b682-9379c6ed8f14" alt="avatar" />
                <div class="post-detail">
                  <h2 class="post-name">Hukum ikhfa</h2>
                  <p class="post-author">Ustadz Ulin Nuha al-Hafidz</p>
                </div>

                <div class="post-actions">
                  <a class="post-like" href="javascript:void(0)"><i class="fas fa-heart"></i></a>

                </div>
              </div>
            </div>

            <div class="swiper-slide post">
              <iframe class="post-img" src="https://www.youtube.com/embed/5hjpzR3uHio">
              </iframe>

              <div class="post-body">
                <img class="post-avatar" src="https://github.com/ecemgo/mini-samples-great-tricks/assets/13468728/b9f5ef94-c2c9-4792-b7a3-593d393f2c84" alt="avatar" />
                <div class="post-detail">
                  <h2 class="post-name">Hukum iqlab</h2>
                  <p class="post-author">Ustadz Ulin Nuha al-Hafidz</p>
                </div>

                <div class="post-actions">
                  <a class="post-like" href="javascript:void(0)"><i class="fas fa-heart"></i></a>

                </div>
              </div>
            </div>

            <div class="swiper-slide post">
              <iframe class="post-img" src="https://www.youtube.com/embed/uLbEKDMB-v0">
              </iframe>

              <div class="post-body">
                <img class="post-avatar" src="https://github.com/ecemgo/mini-samples-great-tricks/assets/13468728/58f9319c-78cf-444b-ba71-701c506c2dd3" alt="avatar" />
                <div class="post-detail">
                  <h2 class="post-name">Hukum idgom</h2>
                  <p class="post-author">Ustadz Ulin Nuha al-Hafidz</p>
                </div>

                <div class="post-actions">
                  <a class="post-like" href="javascript:void(0)"><i class="fas fa-heart"></i></a>


                </div>
              </div>
            </div>

            <div class="swiper-slide post">
              <iframe class="post-img" src="https://www.youtube.com/embed/09e0wnyYsTs">
              </iframe>

              <div class="post-body">
                <img class="post-avatar" src="https://github.com/ecemgo/mini-samples-great-tricks/assets/13468728/24ca2eec-a5ba-4c32-907c-ffffca203e1c" alt="avatar" />
                <div class="post-detail">
                  <h2 class="post-name">hukum nun sukun/tanwin</h2>
                  <p class="post-author">Ustadz Ulin Nuha al-Hafidz</p>
                </div>

                <div class="post-actions">
                  <a class="post-like" href="javascript:void(0)"><i class="fas fa-heart"></i></a>

                </div>
              </div>
            </div>
          </div>
          <div class="swiper-scrollbar"></div>
        </div>
      </div>
    </section>

  </main>

  <footer class="site-footer" id="scaler">
    <div class="container-fot">
      <div class="row">
        <div class="col-sm-12 col-md-6 tex-fut-1 fut-at">
          <h6>About</h6>
          <p class="text-justify">
            Riyadh adalah web pembelajaran bahasa arab buatan <i>SMK Negeri 5 Surakarta</i>,
            web ini dibuat dan dikembangkan oleh Abi, Indra, dan Nico. web ini berisi
            huruf-huruf hijriah, angka-angka arab, cara membaca, dan lain-lain sangat kompit bukann?.
            oh iya, web ini juga ada versi aplikasinya lho dan gak kalah komplit.
          </p>
        </div>

        <div class="col-xs-6 col-md-3 colom-baris-fut colbarfut1">
          <h6>Categories</h6>
          <ul class="footer-links">
            <li>
              <p>Quran online</p>
            </li>
            <li>
              <p>Pembelajaran</p>
            </li>
            <li>
              <p>Pengetahuan</p>
            </li>
            <li>
              <p>Religius</p>
            </li>
          </ul>
        </div>

        <div class="col-xs-6 col-md-3 colom-baris-fut colbarfut2">
          <h6>Quick Links</h6>
          <ul class="footer-links">
            <li>
              <p>About Us</p>
            </li>
            <li>
              <p>Contact Us</p>
            </li>
            <li>
              <p>Contribute</p>
            </li>
          </ul>
        </div>
      </div>
      <hr class="haer">
    </div>
    <div class="container">
      <div class="row-bwh">
        <div class="col-md-8 col-sm-6 col-xs-12 tex-fut-bwh">
          <p class="copyright-text">Copyright &copy; 2024 All Rights Reserved by
            <a href="#">RiyadhLearaning</a>.
          </p>
        </div>

        <div class="col-md-4 col-sm-6 col-xs-12 sosmede">
          <ul class="social-icons">
            <li class="sosm"><a href="https://www.instagram.com/riyadhlearning?igsh=MW5iNGhsNXM3aGFo"><i class="fi fi-brands-instagram"></i></a></li>
            <li class="sosm"><a href="https://twitter.com/riyadhlearning?t=HkZpLR_j-6boElTk551Vsg&s=08"><i class="fi fi-brands-twitter"></i></i></a></li>
            <li class="sosm"><a href="https://wa.me/087739770494"><i class="fi fi-brands-whatsapp"></i></a></li>
            <li class="sosm"><a href="#"><i class="fi fi-brands-pinterest"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>




  <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
  <script src="https://cdpn.io/cpe/boomboom/pen.js?key=pen.js-f948d300-9498-f34b-e114-60774d0fabe0" crossorigin=""></script>
  <script src="https://unpkg.com/typed.js@2.0.16/dist/typed.umd.js"></script>
  <script src="https://unpkg.com/scrollreveal"></script>
  <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
  <script src="script.js"></script>
</body>

</html>