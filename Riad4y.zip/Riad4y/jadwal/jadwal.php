<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="jadwal.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-bold-rounded/css/uicons-bold-rounded.css'>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link rel="stylesheet" href="style.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.1.0/uicons-solid-rounded/css/uicons-solid-rounded.css'>
    <link rel="shortcut icon" href="asset/LOGO.png" type="image/x-icon">
    <link rel="canonical" href="https://codepen.io/coding_dev_/pen/OJqdqLO">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.1.0/uicons-brands/css/uicons-brands.css'>
    <link rel="shortcut icon" href="../asset/LOGO.png" type="image/x-icon">
    <title>Jadwal Sholat</title>
</head>

<body>

    <?php

    $api_url = 'https://api.myquran.com/v2/sholat/kota/semua';

    // membaca JSON dari url
    $kota = file_get_contents($api_url);

    // Decode data JSON data menjadi array PHP
    $response_kota = json_decode($kota);

    // Mengakses data yang ada dalam object 'data'
    $list_kota = $response_kota->data;

    if (isset($_GET['kota'])) {
        $kota_terpilih = $_GET['kota'];
    } else {
        $kota_terpilih = '0119';
    }

    ?>

    <header class="header-sec">
        <div class="logo-smk logo-hij">
        </div>



        </form>
        <a href="../index.php" class="iyako">
            <button>
                <span class="circle1"></span>
                <span class="circle2"></span>
                <span class="circle3"></span>
                <span class="circle4"></span>
                <span class="circle5"></span>
                <span class="text">
                    <i class="fi fi-br-angle-left"></i>
                    <p>Back</p>
                </span>
            </button>
        </a>

    </header>


    <br>
    <br>
    <form method="get" action="">
        <input type="text" id="searchInput" onkeyup="searchFunction()" placeholder="Cari kota...">
        <select name="kota" id="kotaDropdown" class="selecte" onchange="this.form.submit()">
            <?php
            foreach ($list_kota as $k) {
            ?>
                <option <?php if ($kota_terpilih == $k->id) {
                            echo "selected='selected'";
                        } ?> value="<?php echo $k->id ?>"><?php echo $k->lokasi ?></option>
            <?php
            }
            ?>
        </select>
    </form>

    <script>
        function searchFunction() {
            var input, filter, select, option, i;
            input = document.getElementById("searchInput");
            filter = input.value.toUpperCase();
            select = document.getElementById("kotaDropdown");
            option = select.getElementsByTagName("option");
            for (i = 0; i < option.length; i++) {
                if (option[i].innerText.toUpperCase().indexOf(filter) > -1) {
                    option[i].style.display = "";
                } else {
                    option[i].style.display = "none";
                }
            }
        }
    </script>

    <div class="kotak">
        <div class="imsakiyah">
            <table>
                <tr>
                    <th class="yo"><i class="fi fi-br-calendar-day"></i></th>
                    <th>Imsak</th>
                    <th>Subuh</th>
                    <th>Dzuhur</th>
                    <th>Ashar</th>
                    <th>Maghrib</th>
                    <th>Isya</th>
                </tr>
                <?php

                // tentukan bulan puasa
                $api_url = 'https://api.myquran.com/v2/sholat/jadwal/' . $kota_terpilih . '/2024/3';

                // membaca JSON dari url
                $json_data = file_get_contents($api_url);

                // Decode data JSON data menjadi array PHP
                $response_data = json_decode($json_data);

                // Mengakses data yang ada dalam object 'data'
                $jadwal_shalat = $response_data->data;

                foreach ($jadwal_shalat->jadwal as $jadwal) {
                ?>
                    <tr>
                        <th><?php echo $jadwal->tanggal; ?></th>
                        <td><?php echo $jadwal->imsak; ?></td>
                        <td><?php echo $jadwal->subuh; ?></td>
                        <td><?php echo $jadwal->dzuhur; ?></td>
                        <td><?php echo $jadwal->ashar; ?></td>
                        <td><?php echo $jadwal->maghrib; ?></td>
                        <td><?php echo $jadwal->isya; ?></td>
                    </tr>
                <?php
                }
                ?>
            </table>
        </div>

    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="jadwal.js"></script>

</body>

</html>