<?php
$koneksi = mysqli_connect("localhost","root","","multi_user");
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "multi_user";
 

if (mysqli_connect_errno()){
 echo "Koneksi database gagal : " . mysqli_connect_error();
}
function get_pengumuman() {
    $conn = connect_to_db();

    $sql = "SELECT * FROM pengumuman ORDER BY waktu_upload DESC";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        return $result->fetch_all(MYSQLI_ASSOC);
    } else {
        return [];
    }

    $conn->close();
}
?>