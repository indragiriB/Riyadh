
 const scaler = document.getElementById('scaler');
 const bgone = document.getElementById('bgone');
 const lyot = document.getElementById('lyot');

  window.addEventListener('scroll', function() {
    if (window.scrollY > 300) { // Jika halaman discroll ke bawah   
      lyot.style.borderRadius = '0px 0px 0px 0px';
      lyot.style.transition = '1s';
      lyot.style.animationDelay = '.9s';
      
    } else { // Jika halaman discroll ke atas (kembali ke atas)
      scaler.style.transform = 'scale(1)';
      lyot.style.borderRadius = '1000px 1000px 0px 0px';
    }

    if (window.scrollY > 0) {
      scaler.style.transform = 'scale(0.8)';
      scaler.style.transition = '.7s';
    } else { // Jika halaman discroll ke atas (kembali ke atas)
      scaler.style.transform = 'scale(1)';
    }

    

  });