<!-- <?php
        session_start();

        include '../db_connection.php';

        function get_pengumuman()
        {
            $conn = connect_to_db();

            $sql = "SELECT * FROM pengumuman ORDER BY waktu_upload DESC";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                return $result->fetch_all(MYSQLI_ASSOC);
            } else {
                return [];
            }

            $conn->close();
        }
        ?> -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas</title>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-bold-rounded/css/uicons-bold-rounded.css'>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link rel="stylesheet" href="style.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.1.0/uicons-solid-rounded/css/uicons-solid-rounded.css'>
    <link rel="shortcut icon" href="../asset/LOGO.png" type="image/x-icon">
    <link rel="canonical" href="https://codepen.io/coding_dev_/pen/OJqdqLO">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.1.0/uicons-brands/css/uicons-brands.css'>
    <link rel="stylesheet" href="user.css">
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="../hijriah/hijriah.css">
</head>

<body>
    <header class="header-sec">
        <div class="logo-smk logo-hij">

        </div>
        <a href="../index.php" class="iyako">
            <button>
                <span class="circle1"></span>
                <span class="circle2"></span>
                <span class="circle3"></span>
                <span class="circle4"></span>
                <span class="circle5"></span>
                <span class="text">
                    <p>Back</p>
                </span>
            </button>
        </a>
        </div>
    </header>
    <main>
        <section class="sc0 sec-hij">
            <div class="sec-hij-dlm">
                <div class="nama-apk nama-hij" id="scaler">
                    <h1 class="op">Tugas</h1>
                    <p class="op2">Berisi Kumpulan Tugas / Pengumuman dari admin</p>
                </div>
            </div>
        </section>
        <div class="data" id="lyot">
            <ul>
                <?php $pengumuman = get_pengumuman(); ?>
                <?php foreach ($pengumuman as $item) : ?>

                    <li class="data-tugas">
                        <div class="waktune">
                            <p>
                                <?php echo $item['waktu_upload']; ?>
                            </p>
                        </div>
                        <!-- <img src="../asset/LOGO.png" alt=""> -->
                        <div class="head-li">
                            
                            <h3 class="slide"><?php echo $item['judul']; ?>
                            </h3>
                        </div>
                        <script>
                            const headLi = document.querySelector('.head-li');
                            const slide = document.querySelector('.slide');

                            function checkOverflow() {
                                if (slide.offsetWidth > headLi.offsetWidth) {
                                    slide.style.animation = 'slide 10s linear infinite';
                                } else {
                                    slide.style.animation = 'none';
                                }
                            }

                            // Panggil fungsi checkOverflow saat halaman dimuat dan saat ukuran window berubah
                            window.addEventListener('load', checkOverflow);
                            window.addEventListener('resize', checkOverflow);
                        </script>
                        <p class="isinya"><?php echo $item['isi_text']; ?></p>
                        

                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </main>
    <script src="https://unpkg.com/scrollreveal"></script>
    <script src="../script.js"></script>
    <script src="../hijriah/hijriah.js"></script>
</body>

</html>