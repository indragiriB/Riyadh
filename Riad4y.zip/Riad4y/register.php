<?php
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "multi_user";

    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get username and password from the form
    $input_name = $_POST["name"];
    $input_username = $_POST["username"];
    $input_password = $_POST["password"];

    // Automatically assign level to "pegawai"
    $level = "pegawai";

    // Prepare SQL statement to insert user data into database
    $sql = "INSERT INTO user (name, username, password, level) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss",$input_name, $input_username, $input_password, $level);

    // Execute the query
    if ($stmt->execute()) {
        // Registration successful, redirect to login page
        header("Location: logine.php");
        exit();
    } else {
        // Registration failed
        $error_message = "Registration failed. Please try again.";
    }

    // Close statement and database connection
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
</head>

<body>
    <h2>Registration Form</h2>
    <!-- <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name" required><br><br>

        <label for="username">Username:</label><br>
        <input type="text" id="username" name="username" required><br><br>

        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password" required><br><br>

        <label for="level">Level:</label><br>
        <select id="level" name="level">
            <option value="pegawai" selected>Pegawai</option> <!-- Set pegawai sebagai default -->
    </select><br><br>

    <input type="submit" value="Register">
    </form> -->
    <form action="" method="post">
        <div class="flied">
            <input type="text" class="masuk reg" id="nama" name="name" placeholder="..." oninput="checkInput()" required>
            <label for="username" class="ikon ikon2"><i class="fi fi-br-id-badge"></i></label>
            <label class="label label-rg" for="nama_depan">Nama:</label>
            <div id="errorDiv" class="error-message" style="display: none;">
                Minimal 8 karakter
            </div>
        </div>
        <div class="flied">
            <input type="text" class="masuk reg" id="username" name="username" placeholder="..." required>
            <label for="username" class="ikon ikon2"><i class="fi fi-br-circle-user"></i></label>
            <label class="label label-rg" for="nama_depan">Username:</label>

        </div>
        <div class="flied">
            <input type="password" class="masuk reg" id="password" name="password" placeholder="..." required>
            <label for="username" class="ikon ikon2"><i class="fi fi-br-lock"></i></label>
            <label class="label label-rg" for="nama_depan">Password:</label>
        </div>
        <label for="level">Level:</label><br>
        <select id="level" name="level">
            <option value="pegawai" selected>Pegawai</option> <!-- Set pegawai sebagai default -->
        </select><br><br>
        <div class="bawah bawah2">
            <button type="submit" class="tombol_login tombol_reg" name="register" value="login">
                <p>Sign-in</p>
            </button>
            <div onclick="putar()" class="ah ah-blkg">Log-in</div>
        </div>
    </form>
</body>

</html>