



  // Panggil fungsi pertama kali untuk mengatur warna header sesuai dengan keadaan awal
function pro(){
    var pro = document.getElementById("ispro");
    pro.classList.toggle("pro");
}

function buka(){
    var buka = document.getElementById("buka");
    buka.classList.toggle("open");
    var silang = document.getElementById("silang");
    silang.classList.toggle("silang");
    var bgglap = document.getElementById("bgglap");
    bgglap.classList.toggle("ireng"); 
}

function toggleProfile() {
    var profileDiv = document.getElementById("ispro");
    // profileDiv.style.display = (profileDiv.style.display === "none") ? "block" : "none";
    profileDiv.classList.toggle("oee")
}

    var prevScrollpos = window.pageYOffset;
    var hed = document.getElementById("headere");
    var ohy = document.getElementById("buka");
    window.onscroll = function() {
      var currentScrollPos = window.pageYOffset;

      if (prevScrollpos > currentScrollPos) {
        hed.style.top = "0";
        hed.style.opacity = 1;
        
      } else {
        if (!ohy.classList.contains("open")) {
          hed.style.top = "-100px";
          hed.style.opacity = 1;
        } else {
           hed.style.top = "0"; // Change this value if needed
           hed.style.opacity = 1;
        } 
      } 

      

      prevScrollpos = currentScrollPos;
    }

  function putar() {
    var putar = document.getElementById("putar");
    var name = document.getElementById("nama");
    var textInput = document.getElementById("username");
    var passwordInput = document.getElementById("password");
    putar.classList.toggle("putar");
    name.value = "";
    textInput.value = "";
    passwordInput.value = "";
}

const sr = ScrollReveal({
    origin: 'top',
    distance: '40px',
    duration: 2000,
    reset: true     
})

/* -- HOME -- */
sr.reveal('.op',{})
sr.reveal('.op2',{delay:200});
sr.reveal('.imej-kan',{delay:300, distance:'50px'});
sr.reveal('.lampune', {distance:'90px'});
sr.reveal('.sc1-h2', {opacity:0, distance: '50px'})
sr.reveal('.sc1-garis',{delay:900, distance:'0px', scale:0});

const bottom = ScrollReveal({
    origin: 'bottom',
    distance: '10px',
    duration: 2000,
    reset: true     
})

bottom.reveal('.hij',{duration:1500, distance:'50px'})
bottom.reveal('.card',{duration:1500, distance:'150px'})
bottom.reveal('.box-tnd',{duration:1500, distance:'50px'})
bottom.reveal('.sosm:nth-child(1)',{duration: 500, distance:'30px'})
bottom.reveal('.sosm:nth-child(2)',{duration: 1000, distance:'30px'})
bottom.reveal('.sosm:nth-child(3)',{duration: 1500, distance:'30px'})
bottom.reveal('.sosm:nth-child(4)',{duration: 2200, distance:'30px'})
bottom. reveal('.data-tugas', {duration: 1000, distance: '50px'})
bottom. reveal('.haer', {duration: 1000,delay:200, distance: '50px'})
bottom. reveal('.copyright-text', {duration: 1000,delay:400, distance: '50px'})
bottom.reveal('.sc1-p', {duration:1000, distance:'50px', delay:500})
bottom.reveal('.recipe-container', {duration:800, distance:'50px', delay:500})

const left = ScrollReveal({
    origin: 'left',
    distance: '10px',
    duration: 2000,
    reset: true     
})

left.reveal('.fut-at',{duration:1500, distance:'50px'})
left.reveal('.colbarfut2',{duration:1500, distance:'50px', delay:800})
left.reveal('.colbarfut1',{duration:1500, distance:'50px', delay:400})
left.reveal('.btn-about',{});
left.reveal('.menu-buka',{distance:'100px', delay:500});

const right = ScrollReveal({
    origin: 'right',
    distance: '10px',
    duration: 1000,
    reset: true     
})

right.reveal('.btn-explore',{});
right.reveal('.sepan:nth-child(1)',{delay:250, distance:'500px', reset:true});
right.reveal('.sepan:nth-child(2)',{delay:500, distance:'500px', reset:true});
right.reveal('.sepan:nth-child(3)',{delay:760, distance:'500px', reset:true});
right.reveal('.sepan:nth-child(4)',{delay:1000, distance:'500px', reset:true});


const sections = document.querySelectorAll('section[id]')

function scrollActive() {
  const scrollY = window.scrollY;

  sections.forEach(current =>{
    const sectionHeight = current.offsetHeight,
        sectionTop = current.offsetTop - 30,
      sectionId = current.getAttribute('id')

    if(scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) { 

        document.querySelector('.menu-buka a[href*=' + sectionId + ']').classList.add('active-link')

    }  else {

      document.querySelector('.menu-buka a[href*=' + sectionId + ']').classList.remove('active-link')

    }
  })
}

window.addEventListener('scroll', scrollActive)


const sections2 = document.querySelectorAll('section[id]')

function scrollActive2() {
  const scrollY = window.scrollY;

  sections.forEach(current =>{
    const sectionHeight = current.offsetHeight,
        sectionTop = current.offsetTop - 80,
      sectionId = current.getAttribute('id')

    if(scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) { 

        document.querySelector('.vert a[href*=' + sectionId + ']').classList.add('on')

    }  else {

      document.querySelector('.vert a[href*=' + sectionId + ']').classList.remove('on')

    }
  })
}

function su() {
      var yoe = document.getElementById("login");
      yoe.classList.toggle("logine");
  }

const postActionsControllers = document.querySelectorAll(
  ".post-actions-controller"
);

postActionsControllers.forEach((btn) => {
  btn.addEventListener("click", () => {
    const targetId = btn.getAttribute("data-target");
    const postActionsContent = document.getElementById(targetId);

    if (postActionsContent) {
      const isVisible = postActionsContent.getAttribute("data-visible");

      if (isVisible === "false") {
        postActionsContent.setAttribute("data-visible", "true");
        postActionsContent.setAttribute("aria-hidden", "false");
        btn.setAttribute("aria-expanded", "true");
      } else {
        postActionsContent.setAttribute("data-visible", "false");
        postActionsContent.setAttribute("aria-hidden", "true");
        btn.setAttribute("aria-expanded", "false");
      }
    }
  });
});

function handleClickOutside(event) {
  postActionsControllers.forEach((btn) => {
    const targetId = btn.getAttribute("data-target");
    const postActionsContent = document.getElementById(targetId);

    if (postActionsContent && postActionsContent.getAttribute("data-visible") === "true") {
      if (!postActionsContent.contains(event.target) && event.target !== btn) {
        postActionsContent.setAttribute("data-visible", "false");
        postActionsContent.setAttribute("aria-hidden", "true");
        btn.setAttribute("aria-expanded", "false");
      }
    }
  });
}

document.addEventListener("click", handleClickOutside);

postActionsControllers.forEach((btn) => {
  btn.addEventListener("click", (event) => {
    event.stopPropagation();
  });
});

const likeBtns = document.querySelectorAll(".post-like");

likeBtns.forEach((likeBtn) => {
  likeBtn.addEventListener("click", () => {
    if (likeBtn.classList.contains("active")) {
      likeBtn.classList.remove("active");
    } else {
      likeBtn.classList.add("active");
    }
  });
});

// Swiper

let swiper = new Swiper(".swiper", {
  grabCursor: true,
  speed: 400,
  mousewheel: {
    invert: true,
  },
  scrollbar: {
    el: ".swiper-scrollbar",
    draggable: true,
  },
  slidesPerView: 1,
  spaceBetween: 10,
  breakpoints: {
    900: {
      slidesPerView: 2,
      spaceBetween: 20,
    },
    1200: {
      slidesPerView: 3,
      spaceBetween: 20,
    },
  },
});


 const userId = new URLSearchParams(window.location.search).get('user_id');

        fetch(`${userId}`)
            .then(response => response.json())
            .then(data => {
                const userList = document.getElementById('user-list');

                data.forEach(user => {
                    const listItem = document.createElement('li');
                    listItem.textContent = `User ID: ${user.user_id} - Nama: ${user.nama_depan} - Username: ${user.username}`;
                    userList.appendChild(listItem);
                });
            })
            .catch(error => console.error('Error:', error));

