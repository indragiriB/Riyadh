<?php
session_start();

include 'db_connection.php';
include 'koneksi.php';



function is_admin()
{

    return isset($_SESSION['user']['level']) && $_SESSION['user']['level'] == 'admin';
}


function upload_pengumuman($judul, $isi)
{
    $conn = connect_to_db();

    $stmt = $conn->prepare("INSERT INTO pengumuman (judul, isi_text) VALUES (?, ?)");
    $stmt->bind_param("ss", $judul, $isi);

    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }

    $stmt->close();
    $conn->close();
}



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="upload.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-bold-rounded/css/uicons-bold-rounded.css'>
    <link rel="shortcut icon" href="asset/LOGO.png" type="image/x-icon">
    <title>Berhasil Mengupload</title>
</head>

<body>
    <div class="gud">

        <?php
        if (isset($_POST['upload_pengumuman'])) {
            if (is_admin()) {
                $judul = $_POST['judul'];
                $isi = $_POST['isi'];

                if (upload_pengumuman($judul, $isi)) {
                    echo
                    "
            <div class='verivikasi'>
                <div class='isi'>
                    <i class='fi fi-br-check'></i>
                </div>
            </div>
            <div class='sukses'>
                <h6>Upload berhasil!</h6>
            </div>";
                } else {
                    echo
                    "
            <div class='verivikasi'>
                <div class='isi'>
                    <i class='fi fi-br-check'></i>
                </div>
            </div>
            <div class='gagal'>
                <h6>Upload gagal!, Silahkan coba lagi</h6>
            </div>";
                }
            } else {
                echo
                "<div class='tdk'>
        <h6>Anda tidak memiliki izin untuk melakukan tindakan ini.</h6>
        </div>";
            }
        }
        ?>
        <a href="./pengumuman/halaman_user.php" class="iyako">
            <button>
                <span class="circle1"></span>
                <span class="circle2"></span>
                <span class="circle3"></span>
                <span class="circle4"></span>
                <span class="circle5"></span>
                <span class="text">
                    <i class="fi fi-br-angle-left"></i>
                    <p>Halaman user</p>
                </span>
            </button>
        </a>
    </div>
</body>

</html>