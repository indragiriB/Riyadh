  <?php
        session_start();
        include 'koneksi.php';
        // Check if the form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Database connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $database = "multi_user";

            $conn = new mysqli($servername, $username, $password, $database);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Get username and password from the form
            $input_username = $_POST["username"];
            $input_password = $_POST["password"];

            // Prepare SQL statement to retrieve user data
            $sql = "SELECT username, level FROM user WHERE username = ? AND password = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $input_username, $input_password);

            // Execute the query
            $stmt->execute();

            // Get the result
            $result = $stmt->get_result();


            // Check if user exists and credentials are correct
            if ($result->num_rows == 1) {
                // Fetch user data
                $row = $result->fetch_assoc();

                // Set session variables
                $_SESSION["user"]["username"] = $row["username"];
                $_SESSION["user"]["level"] = $row["level"];

                // Redirect to profile.php
                header("Location: index.php");
                exit();
            } else {
                // Invalid username or password
                echo "<div class='error'>Username atau Password salah</div>";
            }



            // Close statement and database connection
            $stmt->close();
            $conn->close();
        }
        ?> 

 <!DOCTYPE html>
 <html lang="en">

 <head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="shortcut icon" href="asset/LOGO.png" type="image/x-icon">
     <link rel="stylesheet" href="login.css">
     <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-bold-rounded/css/uicons-bold-rounded.css'>
     <title>Login</title>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 </head>

 <body id="bg">
     <!-- Login form -->
     <div class="login-peg" id="login" onsubmit="updateProfileClass()">
         <div class="gambar">
             <img class="g1" id="g1" src="asset/Login-bro.png" alt="">
             <img class="g2" id="g2" src="asset/Filing system-bro.png" alt="">
         </div>
         <div class="card-log" id="putar">
             <div class="kotak_login-log depan">

                 <div class="header-log">

                     <h5 class="tulisan_login tul-log" onclick="coyAse()">Login</h5>
                 </div>
                 <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                     <div class="flied">
                         <input type="text" class="masuk" id="username" name="username" autocomplete="off" placeholder="..." required>
                         <label for="username" class="ikon"><i class="fi fi-br-circle-user"></i></label>
                         <label for="username" class="label">Username:</label>

                     </div>
                     <div class="flied">
                         <input type="password" class="masuk" id="password" name="password" autocomplete="off" placeholder="..." required>
                         <div class="ceck" id="matane" onclick="pw()">
                             <i class="fi1 fi-br-eye"></i>
                             <i class="fi2 fi-br-eye-crossed"></i>
                         </div>
                         <label for="username" class="ikon"><i class="fi fi-br-lock"></i></label>
                         <label for="password" class="label">Password:</label>
                     </div>
                     <div class="bawah">
                         <button type="submit" class="tombol_login" name="login" value="login">
                             <P>LOGIN</P>
                         </button>
                         <div class="ah ah-dpan"><i class="fi fi-br-exit"></i></div>
                     </div>
                     <h5 onclick="putar()" class="tex-bwh">Belum punya akun?</h5>
                 </form>
             </div>



             <div class="kotak_login-log belakang" id="log-bwh">

                 <div class="header-log ">
                     <h5 class="tulisan_login tul-sig" onclick="putar()">Sign-in</h5>
                 </div>
                 <form action="register.php" method="post">
                     <div class="flied">
                         <input type="text" class="masuk reg" id="nama" name="name" autocomplete="off" placeholder="..." oninput="checkInput()" required>
                         <label for="username" class="ikon ikon2"><i class="fi fi-br-id-badge"></i></label>
                         <label class="label label-rg" for="nama_depan">Nama:</label>
                         <div id="errorDiv" class="error-message" style="display: none;">
                             Minimal 8 karakter
                         </div>
                     </div>
                     <div class="flied">
                         <input type="text" class="masuk reg" id="username" name="username" autocomplete="off" placeholder="..." required>
                         <label for="username" class="ikon ikon2"><i class="fi fi-br-circle-user"></i></label>
                         <label class="label label-rg" for="nama_depan">Username:</label>

                     </div>
                     <div class="flied">
                         <input type="password" class="masuk reg" id="password2" name="password" autocomplete="off" placeholder="..." required>
                         <div class="ceck ceck-bwh" id="matane2" onclick="pw2()">
                             <i class="fi1 fi-br-eye"></i>
                             <i class="fi2 fi-br-eye-crossed"></i>
                         </div>
                         <label for="username" class="ikon ikon2"><i class="fi fi-br-lock"></i></label>
                         <label class="label label-rg" for="nama_depan">Password:</label>
                     </div>
                     <div class="bawah bawah2">
                         <button type="submit" class="tombol_login tombol_reg" name="register" value="login">
                             <p>SIGN-IN</p>
                         </button>
                         <div onclick="putar()" class="ah ah-blkg"><i class="fi fi-br-plus"></i></div>
                     </div>
                     <h5 onclick="putar()" class="tex-bwh tex-bwh2">Sudah punya akun?</h5>
                 </form>
             </div>
         </div>
     </div>

     <!-- Display error message if login fails -->
     <?php
        if (isset($error_message)) {
            echo "<p class='error'>$error_message</p>";
        }
        ?>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <script src="logine.js"></script>
     <script>
         function putar() {
             var putar = document.getElementById("putar");
             var bg = document.getElementById("bg")
             var name = document.getElementById("nama");
             var textInput = document.getElementById("username");
             var passwordInput = document.getElementById("password");
             var g1 = document.getElementById("g1");
             var g2 = document.getElementById("g2");
             putar.classList.toggle("putar");
             name.value = "";
             textInput.value = "";
             passwordInput.value = "";
             g1.classList.toggle("up");
             g2.classList.toggle("up2");
             bg.classList.toggle("bg");
         }

         function pw() {
             var x = document.getElementById("password");
             var mata = document.getElementById("matane");
             if (x.type === "password") {
                 x.type = "text";
             } else {
                 x.type = "password";
             }
             mata.classList.toggle("mata2");
         }

         function pw2() {
             var x2 = document.getElementById("password2");
             var mata2 = document.getElementById("matane2");
             if (x2.type === "password") {
                 x2.type = "text";
             } else {
                 x2.type = "password";
             }
             mata2.classList.toggle("mata2");
         }
     </script>
 </body>

 </html>