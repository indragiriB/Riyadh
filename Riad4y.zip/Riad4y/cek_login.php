<?php 

session_start();

include 'koneksi.php';
 

$name = $_POST['name'];
$password = $_POST['password'];
 

$login = mysqli_query($koneksi,"select * from user where username='$username' and password='$password'");

$cek = mysqli_num_rows($login);
 


if($cek > 0){
 
 $data = mysqli_fetch_assoc($login);
 

 if($data['level']=="admin"){
 

 $_SESSION['name'] = $name;
 $_SESSION['level'] = "admin";

 header("location:halaman_admin.php");
 

 }else if($data['level']=="pegawai"){

 $_SESSION['name'] = $name;
 $_SESSION['level'] = "pegawai";

 header("location:index.php");


 
 }else{

 header("location:index.php?pesan=gagal");
 } 
}else{
 header("location:index.php?pesan=gagal");
}


function upload_pengumuman($judul, $isi) {
    $conn = connect_to_db();

    $stmt = $conn->prepare("INSERT INTO pengumuman (judul, isi) VALUES (?, ?)");
    $stmt->bind_param("ss", $judul, $isi);

    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }

    $stmt->close();
    $conn->close();
}


if (isset($_POST['upload_pengumuman'])) {
    if (is_admin()) {
        $judul = $_POST['judul'];
        $isi = $_POST['isi'];

        if (upload_pengumuman($judul, $isi)) {
            echo
            "<div class='sukses'>
            <p>Upload berhasil!</p>
            </div>";
        } else {
            echo
            "<div class='gagal'>
            <p>Upload gagal!, Silahkan coba lagi</p>
            </div>";
        }
    } else {
        echo 
        "<div class='tdk'>
        <p>Anda tidak memiliki izin untuk melakukan tindakan ini.</p>
        </div>";
    }
}
 
?>