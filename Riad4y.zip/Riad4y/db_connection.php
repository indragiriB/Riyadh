<?php

function connect_to_db() {
    $host = 'localhost';
    $username = 'root';
    $password = ''; 
    $dbname = 'multi_user'; 

    $conn = new mysqli($host, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    return $conn;
}
?>
