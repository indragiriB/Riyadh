<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.0.0/uicons-bold-rounded/css/uicons-bold-rounded.css'>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link rel="stylesheet" href="admin.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.1.0/uicons-solid-rounded/css/uicons-solid-rounded.css'>
    <link rel="shortcut icon" href="asset/LOGO.png" type="image/x-icon">
    <link rel="canonical" href="https://codepen.io/coding_dev_/pen/OJqdqLO">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.1.0/uicons-brands/css/uicons-brands.css'>
</head>
<?php
session_start();






// var_dump($_SESSION); // Cek isi dari session

// // Fungsi untuk memeriksa apakah pengguna sudah login sebagai admin
// function is_admin() {
//     return isset($_SESSION['level']) && $_SESSION['level'] == 'admin';
// }

?>

<body>
    <!-- <span class="buled"></span>
    <span class="buled"></span>
    <span class="buled"></span>
    <span class="buled"></span>
    <span class="buled"></span>
    <span class="buled"></span>
    <span class="buled"></span> -->

    <header class="header-sec">
        <div class="logo-smk logo-hij">
        </div>
        <a href="index.php" class="iyako">
            <button>
                <span class="circle1"></span>
                <span class="circle2"></span>
                <span class="circle3"></span>
                <span class="circle4"></span>
                <span class="circle5"></span>
                <span class="text">
                    <p>Back</p>
                </span>
            </button>
        </a>
        </div>
    </header>
    <main>
        <span class="lampune"><img src="asset/light_11104988.png" alt="" srcset=""></span>
        <span class="lampune"><img src="asset/light_11104988.png" alt="" srcset=""></span>
        <span class="lampune"><img src="asset/light_11104988.png" alt="" srcset=""></span>
        <h1 id="text" class="judul">Kirim Tugas</h1>
        <form class="form-ad" action="upload_pengumuman.php" method="POST">

            <!-- <div class="inpud">
                    <label for="Judul">Judul</label>
                    <input class="judl" type="text" id="judul" name="judul" autocomplete="off" placeholder="Masukan judul . . ." required>
                </div> -->
            <div class="flied1 fl1">
                <input type="text" class="masuk" type="text" id="judul" name="judul" autocomplete="off" placeholder="Masukan judul . . ." required>
                <label for="text" class="label">Judul</label>
            </div>
            <div class="flied1">
                <label for="flied" class="label label2">Isi</label>
                <div class="flied" name="flied">
                    <textarea class="masuk" id="isi" name="isi" rows="4" cols="50" autocomplete="off" placeholder="Masukan isi disini . . . " required></textarea>
                    <div class="iyako iyako2">
                        <button type="submit" name="upload_pengumuman">
                            Send
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </main>
</body>

</html>